copy http://whatzapp.ml succeed 
the file list :
http://whatzapp.ml => index.html
http://whatzapp.ml/index.css/ => index.css/.css
http://whatzapp.ml/https://code.jquery.com/jquery-3.0.0.min.js => https://code.jquery.com/jquery-3.0.0.min.js
http://whatzapp.ml/wsaap.js => wsaap.js
http://whatzapp.ml/img/carita.png => img/carita.png
http://whatzapp.ml/img/enviar.png => img/enviar.png
create date: 17-01-16 08:36:28
power by cnbluetu
